-- Respaldo de la actualización aplicada. No ejecutar otra vez.
alter table public.pap_atenciones add column numero bigint generated always as identity unique;
alter table public.pap_atenciones add column curso text not null default '' check(length(curso)<=60);
alter table public.pap_atenciones add column formato jsonb not null default '{}';
alter table public.pap_atenciones add column formato_version int not null default 1;
alter table public.pap_atenciones add column fin timestamptz;
alter table public.pap_atenciones add column tiempos jsonb not null default '{}';
alter table public.pap_atenciones add column seguimientos jsonb not null default '[]';
alter table public.pap_atenciones drop constraint pap_atenciones_estudiante_id_fkey;
alter table public.pap_atenciones add constraint pap_atenciones_estudiante_id_fkey foreign key(estudiante_id) references public.estudiantes(id) on delete set null;
create table public.pap_archivos (
 id uuid primary key default gen_random_uuid(), atencion_id uuid not null references public.pap_atenciones(id) on delete cascade,
 version int not null, nombre text not null, ruta text not null unique, tamano bigint not null check(tamano between 1 and 20971520),
 sha256 text not null check(sha256~'^[a-f0-9]{64}$'), completo boolean not null default false, snapshot jsonb not null,
 creado_por uuid not null, creado_en timestamptz not null default now(), unique(atencion_id,version)
);
alter table public.pap_archivos enable row level security;
revoke all on public.pap_archivos from public,anon,authenticated;
grant select on public.pap_archivos to authenticated;
create policy pap_archivos_consulta on public.pap_archivos for select to authenticated using((select orientacion_privado.rol_actual()) in ('orientador','superadministrador','desarrollador'));
create function orientacion_privado.nombre_archivo_pap(p_persona text,p_curso text,p_fecha timestamptz) returns text language sql stable set search_path='' as $$
 select coalesce(nullif(trim(both '_' from regexp_replace(translate(lower(left(p_persona,100)),'áéíóúüñ','aeiouun'),'[^a-z0-9]+','_','g')),''),'estudiante')||'_'||coalesce(nullif(trim(both '_' from regexp_replace(translate(lower(p_curso),'áéíóúüñ','aeiouun'),'[^a-z0-9]+','_','g')),''),'sin_curso')||'_'||to_char(p_fecha at time zone 'America/Bogota','YYYY-MM-DD')||'.pdf'
$$;
revoke all on function orientacion_privado.nombre_archivo_pap(text,text,timestamptz) from public,anon,authenticated;
create or replace function orientacion_privado.pap_flujo(p_accion text,p_id uuid default null,p_datos jsonb default '{}') returns jsonb language plpgsql security definer set search_path='' as $fn$
declare ro text:=orientacion_privado.rol_actual();actor public.perfiles%rowtype;r public.pap_atenciones%rowtype;ar public.pap_archivos%rowtype;busqueda text;campos jsonb;campo jsonb;k text;v text;limpio jsonb:='{}';ti jsonb;seg jsonb;persona_n text;curso_n text;estado_n text;clave text;grupo_campos text[];
begin
 if auth.uid() is null or coalesce(ro,'') not in ('orientador','superadministrador','desarrollador') then raise exception using errcode='42501',message='No tienes acceso a PAP';end if;
 if p_datos is null or jsonb_typeof(p_datos)<>'object' or length(p_datos::text)>180000 then raise exception 'Datos PAP inválidos';end if;
 select * into actor from public.perfiles where auth_user_id=auth.uid();
 if p_accion='listar' then
  busqueda:=lower(btrim(coalesce(p_datos->>'busqueda','')));
  return coalesce((select jsonb_agg(to_jsonb(x) order by x.fecha desc,x.id) from(select p.id,p.numero,p.persona,p.curso,p.fecha,p.estado,p.orientador_nombre,p.orientador_id,p.version,p.formato_version,p.formato->>'proceso' as proceso,
  exists(select 1 from public.pap_archivos a where a.atencion_id=p.id and a.version=p.version and a.completo) as pdf_guardado
  from public.pap_atenciones p where (busqueda='' or strpos(lower(p.persona||' '||p.curso||' '||p.orientador_nombre||' '||p.numero::text),busqueda)>0) and (coalesce(p_datos->>'estado','')='' or p.estado=p_datos->>'estado') order by p.fecha desc,p.id limit 500)x),'[]'::jsonb);
 end if;
 if p_id is null then raise exception 'Falta identificar el registro';end if;
 select * into r from public.pap_atenciones where id=p_id for update;
 if p_accion='detalle' then
  if r.id is null then raise exception 'Registro no disponible';end if;
  return jsonb_build_object('atencion',to_jsonb(r),'nombre_archivo',orientacion_privado.nombre_archivo_pap(r.persona,r.curso,r.fecha),'archivos',coalesce((select jsonb_agg(to_jsonb(a)-'snapshot' order by a.version desc) from public.pap_archivos a where a.atencion_id=p_id),'[]'::jsonb),'historial',coalesce((select jsonb_agg(to_jsonb(x) order by x.fecha desc,x.id desc) from(select h.id,h.fecha,h.actor_nombre,h.accion,jsonb_build_object('persona',h.nuevo->'persona','curso',h.nuevo->'curso','version',h.nuevo->'version') as nuevo,jsonb_build_object('persona',h.anterior->'persona','curso',h.anterior->'curso','version',h.anterior->'version') as anterior from orientacion_privado.pap_historial h where h.registro_id=p_id order by h.fecha desc,h.id desc limit 100)x),'[]'::jsonb));
 end if;
 if p_accion='historial_version' then
  if r.id is null then raise exception 'Registro no disponible';end if;
  return (select to_jsonb(h) from orientacion_privado.pap_historial h where h.registro_id=p_id and h.id=(p_datos->>'cambio_id')::bigint);
 end if;
 if ro<>'orientador' then raise exception using errcode='42501',message='Tu acceso a PAP es de consulta';end if;
 if r.id is not null and r.orientador_id<>actor.id then raise exception using errcode='42501',message='Solo el orientador autor puede diligenciar este registro';end if;
 if p_accion in ('reservar_archivo','confirmar_archivo') then
  if r.id is null then raise exception 'Primero guarda el registro PAP';end if;
  if p_accion='reservar_archivo' then
   if (p_datos->>'version')::int is distinct from r.version then raise exception 'El registro cambió. Vuelve a abrirlo antes de generar el PDF';end if;
   select * into ar from public.pap_archivos where atencion_id=p_id and version=r.version for update;
   if ar.id is null then
    insert into public.pap_archivos(atencion_id,version,nombre,ruta,tamano,sha256,snapshot,creado_por)
    values(p_id,r.version,orientacion_privado.nombre_archivo_pap(r.persona,r.curso,r.fecha),p_id::text||'/'||r.version::text||'/'||gen_random_uuid()::text||'.pdf',(p_datos->>'tamano')::bigint,p_datos->>'sha256',to_jsonb(r),auth.uid()) returning * into ar;
   elsif not ar.completo and not exists(select 1 from storage.objects o where o.bucket_id='pap-archivos' and o.name=ar.ruta) then
    update public.pap_archivos set tamano=(p_datos->>'tamano')::bigint,sha256=p_datos->>'sha256' where id=ar.id returning * into ar;
   end if;
   return to_jsonb(ar)||jsonb_build_object('subido',exists(select 1 from storage.objects o where o.bucket_id='pap-archivos' and o.name=ar.ruta));
  end if;
  select * into ar from public.pap_archivos where id=(p_datos->>'archivo_id')::uuid and atencion_id=p_id for update;
  if not found or not exists(select 1 from storage.objects o where o.bucket_id='pap-archivos' and o.name=ar.ruta and o.metadata->>'mimetype'='application/pdf' and (o.metadata->>'size')::bigint=ar.tamano) then raise exception 'El PDF no terminó de guardarse';end if;
  update public.pap_archivos set completo=true where id=ar.id returning * into ar;return to_jsonb(ar);
 elsif p_accion<>'guardar' then raise exception 'Acción PAP no válida';end if;
 if r.id is not null then
  if (p_datos->>'version')::int is distinct from r.version then raise exception 'El registro cambió. Actualiza antes de editar';end if;
  if r.estado='cerrada' then raise exception 'El registro está cerrado. Crea otro PAP si hay una nueva atención';end if;
 end if;
 if p_datos->>'estudiante_id' is not null then raise exception 'PAP es un archivo independiente; no se vincula a fichas';end if;
 persona_n:=btrim(p_datos->>'persona');curso_n:=btrim(p_datos->>'curso');
 if persona_n is null or length(persona_n) not between 2 and 180 or curso_n is null or length(curso_n) not between 1 and 60 then raise exception 'Completa nombre y curso';end if;
 if jsonb_typeof(p_datos->'formato') is distinct from 'object' then raise exception 'Falta diligenciar el formato';end if;
 campos:='[{"seccion": "Datos del estudiante", "clave": "edad", "etiqueta": "Edad", "tipo": "numero", "requerido": false, "maximo": 3}, {"seccion": "Datos del estudiante", "clave": "identificador", "etiqueta": "Identificador escolar", "tipo": "texto", "requerido": false, "maximo": 100}, {"seccion": "Datos del estudiante", "clave": "acudiente", "etiqueta": "Acudiente", "tipo": "texto", "requerido": false, "maximo": 180}, {"seccion": "Datos del estudiante", "clave": "parentesco", "etiqueta": "Parentesco", "tipo": "texto", "requerido": false, "maximo": 100}, {"seccion": "Datos del estudiante", "clave": "telefono", "etiqueta": "Teléfono del acudiente", "tipo": "texto", "requerido": false, "maximo": 100}, {"seccion": "Datos del estudiante", "clave": "origen", "etiqueta": "Origen de la atención", "tipo": "multiple", "requerido": false, "maximo": 2000, "opciones": ["Solicitud del estudiante", "Docente", "Coordinación", "Familia", "Observación directa", "Otro"]}, {"seccion": "Datos del estudiante", "clave": "origen_otro", "etiqueta": "Otro origen", "tipo": "texto", "requerido": false, "maximo": 250}, {"seccion": "Datos del estudiante", "clave": "remitente", "etiqueta": "Remitente", "tipo": "texto", "requerido": false, "maximo": 180}, {"seccion": "Acercamiento y participación", "clave": "proposito", "etiqueta": "Se explicó el propósito de la ayuda y los límites de la confidencialidad", "tipo": "opcion", "requerido": false, "maximo": 2000, "opciones": ["Sí", "No"]}, {"seccion": "Acercamiento y participación", "clave": "aceptacion", "etiqueta": "El estudiante acepta el acompañamiento", "tipo": "opcion", "requerido": false, "maximo": 2000, "opciones": ["Sí", "No", "No puede expresarlo en este momento"]}, {"seccion": "Acercamiento y participación", "clave": "comunicacion", "etiqueta": "Ajustes de comunicación o apoyo requeridos", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Acercamiento y participación", "clave": "proteccion", "etiqueta": "Si no acepta o no puede responder, situación y medidas de protección adoptadas", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Situación que motivó la atención", "clave": "hecho", "etiqueta": "Descripción del hecho y fuente de la información", "tipo": "area", "requerido": true, "maximo": 4000}, {"seccion": "Situación que motivó la atención", "clave": "expresa", "etiqueta": "Qué expresa el estudiante y qué necesita en este momento", "tipo": "area", "requerido": false, "maximo": 4000}, {"seccion": "Seguridad y necesidades", "clave": "seguridad", "etiqueta": "Seguridad observada", "tipo": "opcion", "requerido": false, "maximo": 2000, "opciones": ["Adecuada", "Requiere traslado a un lugar seguro", "Peligro actual"]}, {"seccion": "Seguridad y necesidades", "clave": "necesidades", "etiqueta": "Necesidades inmediatas", "tipo": "multiple", "requerido": false, "maximo": 2000, "opciones": ["Agua", "Descanso", "Acompañamiento", "Atención médica", "Contacto con persona de confianza", "Otra"]}, {"seccion": "Seguridad y necesidades", "clave": "necesidades_otra", "etiqueta": "Otra necesidad", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Seguridad y necesidades", "clave": "manifestaciones", "etiqueta": "Manifestaciones observadas o referidas", "tipo": "multiple", "requerido": false, "maximo": 2000, "opciones": ["Llanto", "Temor", "Agitación", "Silencio o retraimiento", "Dificultad para concentrarse", "Confusión", "Malestar físico", "Otra"]}, {"seccion": "Seguridad y necesidades", "clave": "manifestaciones_otra", "etiqueta": "Otra manifestación", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Seguridad y necesidades", "clave": "observado", "etiqueta": "Descripción de lo observado y referido sin interpretaciones diagnósticas", "tipo": "area", "requerido": false, "maximo": 4000}, {"seccion": "Seguridad y necesidades", "clave": "alertas", "etiqueta": "Alertas identificadas o sospechadas", "tipo": "multiple", "requerido": false, "maximo": 2000, "opciones": ["Ninguna identificada al momento", "No se logra establecer", "Urgencia médica", "Autolesión o posible riesgo suicida", "Amenaza de daño a otras personas", "Posible violencia o vulneración de derechos", "Otra"]}, {"seccion": "Seguridad y necesidades", "clave": "alerta_otra", "etiqueta": "Otra alerta", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Seguridad y necesidades", "clave": "medidas", "etiqueta": "Alerta concreta y medidas inmediatas tomadas", "tipo": "area", "requerido": false, "maximo": 4000}, {"seccion": "Escucha y apoyo brindado", "clave": "acciones", "etiqueta": "Acciones realizadas", "tipo": "multiple", "requerido": false, "maximo": 2000, "opciones": ["Presentación y explicación de la ayuda", "Escucha sin presionar", "Validación de emociones", "Acompañamiento en espacio tranquilo", "Apoyo práctico", "Orientación para recuperar la calma según tolerancia", "Información clara sobre próximos pasos", "Otra"]}, {"seccion": "Escucha y apoyo brindado", "clave": "accion_otra", "etiqueta": "Otra acción", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Escucha y apoyo brindado", "clave": "ayuda", "etiqueta": "Descripción de la ayuda brindada y respuesta del estudiante", "tipo": "area", "requerido": true, "maximo": 4000}, {"seccion": "Conexión con apoyos", "clave": "confianza", "etiqueta": "Persona de confianza identificada", "tipo": "texto", "requerido": false, "maximo": 180}, {"seccion": "Conexión con apoyos", "clave": "confianza_vinculo", "etiqueta": "Vínculo de la persona de confianza", "tipo": "texto", "requerido": false, "maximo": 100}, {"seccion": "Conexión con apoyos", "clave": "apoyos", "etiqueta": "Apoyos disponibles", "tipo": "multiple", "requerido": false, "maximo": 2000, "opciones": ["Familia", "Orientación", "Docente", "Salud", "Protección", "Otro"]}, {"seccion": "Conexión con apoyos", "clave": "apoyos_otro", "etiqueta": "Otro apoyo", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Conexión con apoyos", "clave": "pendientes", "etiqueta": "Necesidades pendientes y apoyos que se gestionan", "tipo": "area", "requerido": false, "maximo": 4000}, {"seccion": "Comunicación y activación de rutas", "clave": "contacto_estado", "etiqueta": "Contacto con acudiente o adulto seguro", "tipo": "opcion", "requerido": false, "maximo": 2000, "opciones": ["Logrado", "Sin respuesta", "Pendiente", "No procede por razones de protección"]}, {"seccion": "Comunicación y activación de rutas", "clave": "contacto_motivo", "etiqueta": "Motivo del estado del contacto", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Comunicación y activación de rutas", "clave": "contacto_persona", "etiqueta": "Persona contactada", "tipo": "texto", "requerido": false, "maximo": 180}, {"seccion": "Comunicación y activación de rutas", "clave": "contacto_vinculo", "etiqueta": "Vínculo de la persona contactada", "tipo": "texto", "requerido": false, "maximo": 100}, {"seccion": "Comunicación y activación de rutas", "clave": "contacto_telefono", "etiqueta": "Teléfono de la persona contactada", "tipo": "texto", "requerido": false, "maximo": 100}, {"seccion": "Comunicación y activación de rutas", "clave": "contacto_medio", "etiqueta": "Medio utilizado", "tipo": "texto", "requerido": false, "maximo": 250}, {"seccion": "Comunicación y activación de rutas", "clave": "contacto_info", "etiqueta": "Información relevante comunicada y respuesta recibida", "tipo": "area", "requerido": false, "maximo": 4000}, {"seccion": "Comunicación y activación de rutas", "clave": "destino", "etiqueta": "Destino de la ruta", "tipo": "opcion", "requerido": false, "maximo": 2000, "opciones": ["Orientación", "Servicio de salud", "Emergencias", "Protección", "No requiere remisión"]}, {"seccion": "Comunicación y activación de rutas", "clave": "receptora", "etiqueta": "Entidad o persona receptora", "tipo": "texto", "requerido": false, "maximo": 250}, {"seccion": "Comunicación y activación de rutas", "clave": "recepcion", "etiqueta": "Entrega o recepción confirmada", "tipo": "opcion", "requerido": false, "maximo": 2000, "opciones": ["Sí", "No", "Pendiente"]}, {"seccion": "Comunicación y activación de rutas", "clave": "continuidad", "etiqueta": "Si no se logra contacto o recepción, acción de continuidad", "tipo": "area", "requerido": false, "maximo": 4000}, {"seccion": "Cierre y acuerdos", "clave": "estado_final", "etiqueta": "Estado al finalizar", "tipo": "opcion", "requerido": false, "maximo": 2000, "opciones": ["Menor malestar referido u observado", "Malestar persiste", "Empeora", "No se puede determinar"]}, {"seccion": "Cierre y acuerdos", "clave": "estado_descripcion", "etiqueta": "Descripción del estado al finalizar", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Cierre y acuerdos", "clave": "disposicion", "etiqueta": "Disposición", "tipo": "opcion", "requerido": false, "maximo": 2000, "opciones": ["Retoma actividades con apoyo", "Permanece acompañado en el colegio", "Entrega a adulto seguro", "Traslado a servicio", "Otra"]}, {"seccion": "Cierre y acuerdos", "clave": "disposicion_otra", "etiqueta": "Otra disposición", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Cierre y acuerdos", "clave": "recibe", "etiqueta": "Persona que recibe o acompaña", "tipo": "texto", "requerido": false, "maximo": 180}, {"seccion": "Cierre y acuerdos", "clave": "acuerdos", "etiqueta": "Acuerdos concretos con el estudiante y la red de apoyo", "tipo": "area", "requerido": false, "maximo": 4000}, {"seccion": "Plan de seguimiento", "clave": "proximo_contacto", "etiqueta": "Plan para el próximo contacto", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Plan de seguimiento", "clave": "plan_medio", "etiqueta": "Medio de contacto previsto", "tipo": "texto", "requerido": false, "maximo": 250}, {"seccion": "Plan de seguimiento", "clave": "verificar", "etiqueta": "Aspecto a verificar", "tipo": "area", "requerido": false, "maximo": 2000}, {"seccion": "Plan de seguimiento", "clave": "proceso", "etiqueta": "Estado del proceso", "tipo": "opcion", "requerido": true, "maximo": 2000, "opciones": ["Seguimiento activo", "Remitido con recepción confirmada", "Cierre PAP"]}, {"seccion": "Plan de seguimiento", "clave": "justificacion", "etiqueta": "Justificación y apoyos que continúan", "tipo": "area", "requerido": true, "maximo": 4000}]'::jsonb;
 for campo in select * from jsonb_array_elements(campos) loop
  k:=campo->>'clave';
  if campo->>'tipo'='multiple' then
   if p_datos->'formato'->k is not null and jsonb_typeof(p_datos->'formato'->k)<>'array' then raise exception 'Selección no válida en %',k;end if;
   if exists(select 1 from jsonb_array_elements_text(coalesce(p_datos->'formato'->k,'[]'::jsonb)) op where not ((campo->'opciones') ? op)) then raise exception 'Opción desconocida en %',k;end if;
   limpio:=limpio||jsonb_build_object(k,coalesce(p_datos->'formato'->k,'[]'::jsonb));
  else
   v:=btrim(coalesce(p_datos->'formato'->>k,''));
   if length(v)>(campo->>'maximo')::int or ((campo->>'requerido')::boolean and length(v)<3) then raise exception 'Revisa el campo %',campo->>'etiqueta';end if;
   if campo->>'tipo'='opcion' and v<>'' and not ((campo->'opciones') ? v) then raise exception 'Opción no válida en %',k;end if;
   limpio:=limpio||jsonb_build_object(k,v);
  end if;
 end loop;
 if limpio->>'edad'<>'' and (limpio->>'edad'!~'^[0-9]{1,3}$' or (limpio->>'edad')::int not between 1 and 120) then raise exception 'Revisa la edad';end if;
 if (limpio->'alertas' ? 'Ninguna identificada al momento' or limpio->'alertas' ? 'No se logra establecer') and jsonb_array_length(limpio->'alertas')>1 then raise exception 'Revisa las alertas: las opciones de ausencia o incertidumbre se seleccionan solas';end if;
 if length(limpio->>'hecho')<3 or length(limpio->>'ayuda')<3 then raise exception 'Describe el hecho y la ayuda brindada';end if;
 if limpio->>'proceso'='Remitido con recepción confirmada' and (limpio->>'recepcion'<>'Sí' or coalesce(limpio->>'destino','') in ('','No requiere remisión')) then raise exception 'Indica el destino y confirma la recepción de la ruta';end if;
 estado_n:=case when limpio->>'proceso'='Cierre PAP' then 'cerrada' else 'seguimiento' end;
 if estado_n='cerrada' and length(limpio->>'acuerdos')<3 then raise exception 'Registra los acuerdos antes de cerrar';end if;
 ti:=coalesce(r.tiempos,'{}'::jsonb);
 foreach clave in array array['contacto','ruta','entrega','alerta'] loop
  grupo_campos:=case clave when 'contacto' then array['contacto_estado','contacto_persona','contacto_vinculo','contacto_telefono','contacto_medio','contacto_info'] when 'ruta' then array['destino','receptora','recepcion','continuidad'] when 'entrega' then array['recibe','disposicion','disposicion_otra'] else array['medidas','alerta_otra'] end;
  if exists(select 1 from unnest(grupo_campos) cc where coalesce(limpio->>cc,'')<>'' and (limpio->cc is distinct from r.formato->cc)) then ti:=ti||jsonb_build_object(clave,jsonb_build_object('fecha',now(),'orientador',actor.nombre));end if;
 end loop;
 seg:=coalesce(r.seguimientos,'[]'::jsonb);
 v:=btrim(coalesce(p_datos->>'seguimiento_nuevo',''));
 if length(v)>4000 then raise exception 'El seguimiento es demasiado extenso';end if;
 if v<>'' then seg:=seg||jsonb_build_array(jsonb_build_object('fecha',now(),'orientador',actor.nombre,'resultado',v));end if;
 if r.id is null then
  insert into public.pap_atenciones(id,estudiante_id,persona,curso,fecha,lugar,motivo,situacion,acciones,apoyo,acuerdos,seguimiento,estado,orientador_id,orientador_nombre,formato,formato_version,tiempos,seguimientos,fin)
  values(p_id,null,persona_n,curso_n,now(),'',limpio->>'hecho',limpio->>'observado',limpio->>'ayuda',limpio->>'pendientes',limpio->>'acuerdos',null,estado_n,actor.id,actor.nombre,limpio,2,ti,seg,case when estado_n='cerrada' then now() end) returning * into r;
 else
  update public.pap_atenciones set estudiante_id=null,persona=persona_n,curso=curso_n,lugar='',motivo=limpio->>'hecho',situacion=limpio->>'observado',acciones=limpio->>'ayuda',apoyo=limpio->>'pendientes',acuerdos=limpio->>'acuerdos',seguimiento=null,estado=estado_n,formato=limpio,formato_version=2,tiempos=ti,seguimientos=seg,fin=case when estado_n='cerrada' then now() end,version=version+1,actualizado_en=now() where id=p_id returning * into r;
 end if;
 return to_jsonb(r);
end $fn$;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('pap-archivos','pap-archivos',false,20971520,array['application/pdf']);
create function orientacion_privado.pap_archivo_acceso(p_ruta text,p_escritura boolean) returns boolean language sql stable security definer set search_path='' as $$
 select auth.uid() is not null and exists(select 1 from public.pap_archivos a join public.pap_atenciones p on p.id=a.atencion_id where a.ruta=p_ruta and (
 (not p_escritura and orientacion_privado.rol_actual() in ('orientador','superadministrador','desarrollador')) or
 (p_escritura and orientacion_privado.rol_actual()='orientador' and p.orientador_id=(select id from public.perfiles where auth_user_id=auth.uid()) and not a.completo)));
$$;
revoke all on function orientacion_privado.pap_archivo_acceso(text,boolean) from public,anon;
grant execute on function orientacion_privado.pap_archivo_acceso(text,boolean) to authenticated;
create policy pap_pdf_lectura on storage.objects for select to authenticated using(bucket_id='pap-archivos' and orientacion_privado.pap_archivo_acceso(name,false));
create policy pap_pdf_subida on storage.objects for insert to authenticated with check(bucket_id='pap-archivos' and orientacion_privado.pap_archivo_acceso(name,true));
